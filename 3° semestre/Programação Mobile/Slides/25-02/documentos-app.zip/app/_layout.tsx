import { Stack } from 'expo-router';

export default function Layout() {
    return (
        <Stack>
            <Stack.Screen
                name="index"
                options={{ title: 'Menu Principal' }}
            />
            <Stack.Screen
                name="cartao/pesquisaScreen"
                options={{ title: 'Pesquisa de Cartões' }}
            />
            <Stack.Screen
                name="cartao/cadastroScreen"
                options={{ title: 'Cadastro de Cartão' }}
            />            
        </Stack>
    );
}