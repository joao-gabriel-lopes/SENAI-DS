import { View } from 'react-native';

export default function PesquisaScreen() {
  return (
    <View></View>
  );
}
