import { useRouter } from 'expo-router';
import { Button, View } from 'react-native';

export default function Index() {
    const router = useRouter();

    return (
        <View>
            <Button
                title='Abrir Pesquisa'
                onPress={() => router.push('cartao/pesquisaScreen')}
            />
            <Button
                title='-Abrir Cadastro'
                onPress={() => router.push('cartao/cadastroScreen')}
            />
        </View>
    );
}

