<?php

function GetConexao()
{
    $host = '127.0.0.1:3306';
    $banco = 'ALMOXARIFADO';
    $usuario = 'root';
    $senha = 'root';

    $stringConexao = "mysql:host=" . $host . ";dbname=" . $banco;
    $conexao = new PDO($stringConexao, $usuario, $senha);
    return $conexao;
}
