<?php
require_once 'conexao.php';

$email_informado = $_POST['email'] ?? '';
$senha_informada = $_POST['senha'] ?? '';

try {
    $conexao = GetConexao();

    //O uso do BindParam protege o sistema contra SQL Injection
    $usarBindParam = false;

    //Se "true", monta o SQL usando parâmetros    
    if ($usarBindParam) {
        $sql =
            "SELECT ID, EMAIL, SENHA 
             FROM USUARIO 
             WHERE EMAIL = :EMAIL AND SENHA = :SENHA";

        $comando = $conexao->prepare($sql);
        $comando->bindParam(':EMAIL', $email_informado);
        $comando->bindParam(':SENHA', $senha_informada);

    //Se "false", monta o SQL usando concatenação (Vulnerável à SQL Injection)    
    } else {
        $sql =
            "SELECT ID, EMAIL, SENHA 
             FROM USUARIO
             WHERE EMAIL = '$email_informado' AND SENHA = '$senha_informada'";

        $comando = $conexao->query($sql);
    }
    
    echo "SQL: $sql";
    $comando->execute();

    $usuario = $comando->fetch();

    if ($usuario) {
        echo "<p>Login bem-sucedido. Bem-vindo, " . $usuario['EMAIL'] . "!</p>";
    } else {
        echo "<p>Usuário ou senha inválidos.</p>";
    }
} catch (Exception $e) {
    echo "<p>Erro no login: </p>";
    echo "<br>" . $e->getMessage();
}
