
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do PIX</title>
    <link rel="stylesheet" href="realizarPix.css">
</head>
<body>
    <div class="status">
        <?= $mensagem ?>
    </div>

    <table>
        <thead>
            <tr>
                <th>NÚMERO</th>
                <th>PROPRIETÁRIO</th>
                <th>SALDO</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lista_contas as $conta): ?>
                <tr>
                    <td><?= $conta['NUMERO'] ?></td>
                    <td><?= $conta['PROPRIETARIO'] ?></td>
                    <td>
                        R$ <?= number_format($conta['SALDO'], 2, ',', '.') ?>

                        <?php if ($conta['NUMERO'] === $numero_conta_origem): ?>
                            <span class="valor-movimento negativo">(- R$ <?= number_format($p_valor, 2, ',', '.') ?>)</span>
                        <?php elseif ($conta['NUMERO'] === $numero_conta_destino): ?>
                            <span class="valor-movimento positivo">(+ R$ <?= number_format($p_valor, 2, ',', '.') ?>)</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="voltar">
        <a href="index.php">← Voltar</a>
    </div>
</body>
</html>
