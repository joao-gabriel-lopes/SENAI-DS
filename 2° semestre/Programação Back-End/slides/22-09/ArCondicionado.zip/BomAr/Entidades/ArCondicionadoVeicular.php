<?php
require_once 'ArCondicionado.php';

class ArCondicionadoVeicular extends ArCondicionado
{
    private $temperaturaMaxima;
    private $temperaturaMinima;
    private $modelo;

    public function __construct($lig, $temp, $tempMax, $tempMin, $mod)
    {
        $this->ligado = $lig;        
        $this->temperaturaMaxima = $tempMax;
        $this->temperaturaMinima = $tempMin;
        $this->modelo = $mod;
        $this->SetTempertura($temp);
    }

    public function GetDados(){
        return
            "ligado: {$this->ligado}" . "<br>" .
            "TemperaturaAtual: {$this->temperaturaAtual}" . "<br>" .
            "TemperaturaMáxima: {$this->temperaturaMaxima}" . "<br>" .
            "TemperaturaMinima: {$this->temperaturaMinima}" . "<br>" .
            "Modelo: {$this->modelo}" . "<br><br>";
    }

    protected function SetTempertura($temp)
    {
        if ($this->ligado) {
            if ($temp > $this->temperaturaMaxima) {
                $this->temperaturaAtual = $this->temperaturaMaxima;
            } else 
            if ($temp < $this->temperaturaMinima) {
                $this->temperaturaAtual = $this->temperaturaMinima;
            } else {
                
            }
        }
    }

    public function AumentarTemperatura()
    {
        $this->SetTempertura($this->temperaturaAtual + 2);
        return $this->temperaturaAtual;
    }
    public function DiminuirTemperatura()
    {
        $this->SetTempertura($this->temperaturaAtual - 2);
        return $this->temperaturaAtual;
    }
}
