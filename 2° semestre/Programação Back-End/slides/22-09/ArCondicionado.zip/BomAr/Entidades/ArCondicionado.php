<?php
require_once 'IArCondicionado.php';

abstract class ArCondicionado implements IArCondicionado
{
    protected $ligado;
    protected $temperaturaAtual;

    public function __construct($lig, $temp)
    {
        $this->ligado = $lig;        
        $this->SetTempertura($temp);
    }

    protected abstract function SetTempertura($temp);

    public function Ligar()
    {
        $this->ligado = true;
        return $this->ligado;
    }

    public function Desligar()
    {
        $this->ligado = false;
        return $this->ligado;
    }

    public abstract function AumentarTemperatura();
    public abstract function DiminuirTemperatura();
}
