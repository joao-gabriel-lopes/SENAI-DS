<?php
    require_once 'Entidades/ArCondicionadoVeicular.php';
    require_once 'Entidades/ArCondicionadoPredial.php';

    $arcond1 = new ArCondicionadoVeicular(
        true, 24, 25, 16, 'Fujitsu XYZ'
    );    
    echo $arcond1->GetDados();
    $arcond1->AumentarTemperatura();
    echo $arcond1->GetDados();    

    echo "<br>";

    $arcond2 = new ArCondicionadoPredial(
        true, 26, 24, 15, 'Fujitsu ABC'
    );
    echo $arcond2->GetDados();
    $arcond2->DiminuirTemperatura();
    echo $arcond2->GetDados();     
    
    $arcond2->Desligar();
    echo $arcond2->GetDados();    
    
    $arcond1->Desligar();
    echo $arcond1->GetDados();

?>