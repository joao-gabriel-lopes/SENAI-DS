    <?php

    require_once "autenticar.php";

    session_start();
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $usuario = Autenticar($email, $senha);

    if ($usuario == false){
        header ("Location: index.php");
    }

    $cor = $_COOKIE['cor'] ?? "black";
    echo "Cor: " . $cor;

    ?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>

    <body>

        <p style="color: <?= $cor ?>">Bem vindo <?= $usuario['NOME'] ?>  </p>
    </body>

    </html>