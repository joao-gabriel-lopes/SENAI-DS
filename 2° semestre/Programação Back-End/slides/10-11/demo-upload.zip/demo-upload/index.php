<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="exibir_imagem.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="arquivo" id="arquivo"> <br><br><br>
        <input type="submit" value="Enviar"> 
    </form>
</body>

</html>