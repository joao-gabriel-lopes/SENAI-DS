<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    // Salva o caminho do diretório "imagens" numa variável
    // "__DIR__" indica o diretório raiz do projeto
    $diretorio = __DIR__ . "/imagens/";

    // Se não existe o diretório, cria com permissão total (0777)
    if (!file_exists($diretorio)) {
        mkdir($diretorio, 0777, true);
    }

    // Salva o arquivo recebido na variável carregada na memória
    $arquivo_imagem = $_FILES['arquivo'];

    // Copia somente o nome (e não o caminho) do arquivo recebido
    $destino_arquivo = $diretorio . $arquivo_imagem['name'];

    // Move o arquivo para o diretório criado, com o mesmo nome
    move_uploaded_file($arquivo_imagem['tmp_name'], $destino_arquivo);
    echo "<br> Nome temporário: " . $arquivo_imagem['tmp_name'];
    echo "<br> Nome definitivo: " . $destino_arquivo;
    ?>

    <br><br>
    <a href="index.php">Voltar</a> <br><br>
    <img src="imagens/<?= $arquivo_imagem['name'] ?>" alt="imagem recebida">
</body>

</html>