<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $email = $_COOKIE['email'] ?? "";
    $senha = $_COOKIE['senha'] ?? "";
    $cor = $_COOKIE['cor'] ?? "black";

    if ($email == "" || $senha == "") {
        header("Location: index.php");
    }
    ?>

    <p style="color: <?= $cor ?>">Bem vindo <?= $email ?> </p>
</body>

</html>