<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Lista de Pokémons</title>
    <link rel="stylesheet" href="listar_pokemons.css">
</head>

<body>
    <div class="container">
        <h1>Pokédex - Lista de Pokémons</h1>

        <a href="exibir_pokemon.php" class="botao-adicionar">+ Adicionar Novo Pokémon</a>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Foto</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td> Exemplo de ID </td>
                    <td>
                        <img src="">
                    </td>
                    <td></td>
                    <td>
                        <a href="exibir_pokemon.php? class="botao-visualizar">Visualizar</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>