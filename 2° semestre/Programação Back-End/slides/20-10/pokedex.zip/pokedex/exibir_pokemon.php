<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Pokedex</title>
    <link rel="stylesheet" href="exibir_pokemon.css">
</head>

<body>
    <form method="post">
        <section>
            <h1>Pokédex Nº</h1>

            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome">

            <label for="descricao">Descrição:</label>
            <textarea name="descricao" id="descricao"></textarea>

            <label for="foto">Foto:</label>
            <input type="file" name="foto" id="foto" accept="image/*">
            <input type="hidden" name="fotoNome" id="fotoNome" readonly>

            <input type="submit" value="Salvar">
        </section>

        <section>
            <img id="preview" src="imagens/interrogação.png" alt="Pré-visualização da imagem">
        </section>
    </form>

<script>
        const inputFoto = document.getElementById('foto');
        const inputFotoNome = document.getElementById('fotoNome');
        const preview = document.getElementById('preview');

        inputFoto.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                inputFotoNome.value = file.name;
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                inputFotoNome.value = '';
                preview.src = 'imagens/interrogação.png';
            }
        });
    </script>
</body>

</html>