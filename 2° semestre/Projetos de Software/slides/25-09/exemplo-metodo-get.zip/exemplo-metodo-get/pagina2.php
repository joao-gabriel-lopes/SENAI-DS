<?php
require_once 'dados.php';
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exibir Pessoa</title>
</head>

<body>
    <?php
    $idGet = (int)$_GET['id'];

    $pessoaSelecionada = null;
    foreach ($listaPessoas as $p) {
        if ($idGet === $p->GetId()) {
            $pessoaSelecionada = $p;
            break;
        }
    }
    ?>

    <?php if (isset($pessoaSelecionada)) { ?>

        <label for="id">Id: </label> <br>
        <input name="id" type="text" value="<?php echo $pessoaSelecionada->GetId(); ?>"> <br>

        <label for="id">Nome: </label> <br>
        <input name="nome" type="text" value="<?php echo $pessoaSelecionada->GetNome(); ?>"> <br>

    <?php } else { ?>
        <p>Pessoa não encontrada.</p>
    <?php } ?>

</body>

</html>