<?php
    class Pessoa{
        private $id;
        private $nome;

        public function __construct($id, $nome)
        {
            $this->id = $id;
            $this->nome = $nome;
        }

        public function GetId(){
            return $this->id;
        }
        public function GetNome(){
            return $this->nome;
        }
    }

    $listaPessoas = [
        new Pessoa(1, 'Alexandre'),
        new Pessoa(2, 'Bruno'),
        new Pessoa(3, 'Luciana')
    ];
?>
