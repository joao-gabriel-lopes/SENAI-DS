<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pessoas</title>
</head>
<body>
    <p>
        Cada link chama "pagina2.php", mas passando, pelo método "GET" um id diferente
        
    </p>

    <a href="pagina2.php?id=1">Pessoa 1</a> (link: pagina2.php?id=1) <br>
    <a href="pagina2.php?id=2">Pessoa 2</a> (link: pagina2.php?id=2)<br>
    <a href="pagina2.php?id=3">Pessoa 3</a> (link: pagina2.php?id=3)<br>
</body>
</html>