<?php
require_once '../Dados/ListaEstoque.php';

$itemId = isset($_GET['id']) ? (int)$_GET['id'] : null;

$itemSelecionado = null;
foreach ($itens as $item) {
    if ($item->getId() === $itemId) {
        $itemSelecionado = $item;
        break;
    }
}

if (!$itemSelecionado) {
    echo "<h2>Item de estoque não encontrado.</h2>";
    echo "<a href='ExibirEstoque.php'>Voltar</a>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Ficha do Item - <?= $itemSelecionado->getNome(); ?></title>
    <link rel="stylesheet" href="FichaEstoque.css">
</head>

<body>

    <h1>Ficha do Item de Estoque</h1>

    <form action="../Funcoes/SalvarAlteracoes.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $itemSelecionado->getId(); ?>">

        <label for="nome">Nome do Item:</label>
        <input type="text" name="nome" id="nome" value="<?= $itemSelecionado->getNome(); ?>" required>

        <label for="descricao">Descrição:</label>
        <textarea name="descricao" id="descricao" rows="5" required><?= $itemSelecionado->getDescricao(); ?></textarea>



        <label for="quantidade">Quantidade Mínima:</label>
        <input type="number" name="quantidade" id="quantidade" value="<?= $itemSelecionado->getQuantidadeMinima(); ?>" required>



        <label for="codigo">Código:</label>
        <input type="text" name="codigo" id="codigo" value="<?= $itemSelecionado->getCodigo(); ?>" required>


        <label for="categoria">Categoria:</label>
        <select name="categoria_id" id="categoria" required>
            <?php foreach ($categorias as $categoria): ?>
                <option value="<?= $categoria->getId(); ?>"
                    <?= $categoria->getId() === $itemSelecionado->getCategoria()->getId() ? 'selected' : ''; ?>>
                    <?= $categoria->getNome(); ?>
                </option>
            <?php endforeach; ?>
        </select>



        <label>Imagem Atual:</label><br>
        <img src="<?= '../Imagens/' . $itemSelecionado->getNomeImagem(); ?>" alt="<?= $itemSelecionado->getNome(); ?>" width="150">


        <label for="imagem">Alterar Imagem (opcional):</label>
        <input type="file" name="imagem" id="imagem">


        <div class="form-buttons">
            <button type="submit">Salvar</button>
            <a href="ExibirEstoque.php" class="btn-voltar">Voltar</a>
        </div>

        <?php
        $mensagemSucesso = isset($_GET['mensagem']) ? $_GET['mensagem'] : null;
        ?>

        <?php if ($mensagemSucesso) { ?>
            <div class="mensagem-sucesso">
                <?= $mensagemSucesso; ?>
            </div>
        <?php }; ?>

    </form>

</body>

</html>