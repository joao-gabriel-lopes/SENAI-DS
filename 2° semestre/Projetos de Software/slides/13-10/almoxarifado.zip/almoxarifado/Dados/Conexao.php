<?php
class Conexao {
    private static $host = '127.0.0.1:3306';
    private static $banco = 'almoxarifado';
    private static $usuario = 'root';
    private static $senha = 'root';

    private static $conexaoPDO = null;

    private function __construct() {}

    public static function GetConexao() {
        if (self::$conexaoPDO === null) {
            try {
                $stringConexao = "mysql:host=" . self::$host . ";dbname=" . self::$banco;
                self::$conexaoPDO = new PDO($stringConexao, self::$usuario, self::$senha);
            } catch (PDOException $e) {
                throw new Exception("Erro ao conectar ao banco de dados: " . $e->getMessage());
            }
        }
        return self::$conexaoPDO;
    }
}
?>
