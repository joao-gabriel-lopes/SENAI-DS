<?php
require_once '../Modelos/Localizacao.php';
require_once '../Modelos/Categoria.php';
require_once '../Modelos/ItemEstoque.php';
require_once 'Conexao.php';

$conexao = Conexao::GetConexao();

$sql = "SELECT ID, NOME, DESCRICAO FROM LOCALIZACAO ORDER BY ID";
$comando = $conexao->prepare($sql);
$comando->execute();
$lista = $comando->fetchAll();

$localizacoes = [];

foreach ($lista as $item) {
    array_push(
        $localizacoes,
        new Localizacao(
            $item['ID'],
            $item['NOME'],
            $item['DESCRICAO']
        )
    );
}

$sql = "SELECT ID, NOME, DESCRICAO, LOCALIZACAO_ID FROM CATEGORIA ORDER BY ID";
$comando = $conexao->prepare($sql);
$comando->execute();
$lista = $comando->fetchAll();

$categorias = [];
foreach ($lista as $item) {
    $localizacao = null;
    foreach ($localizacoes as $itemLocalizacao) {
        if ($itemLocalizacao->GetId() == $item['LOCALIZACAO_ID']) {
            $localizacao = $itemLocalizacao;
            break;
        }
    }

    array_push($categorias, new Categoria(
        $item['ID'],
        $localizacao,
        $item['NOME'],
        $item['DESCRICAO']
    ));
}

$sql = "SELECT ID, CATEGORIA_ID, NOME, DESCRICAO, QUANTIDADE, CODIGO, IMAGEM FROM ITEMESTOQUE ORDER BY ID";
$comando = $conexao->prepare($sql);
$comando->execute();
$lista = $comando->fetchAll();

$itens = [];
foreach ($lista as $item) {
    $categoria = null;
    foreach ($categorias as $itemCategoria) {
        if ($itemCategoria->GetId() == $item['CATEGORIA_ID']) {
            $categoria = $itemCategoria;
            break;
        }
    }

    array_push($itens, new ItemEstoque(
        $item['ID'],
        $categoria,
        $item['NOME'],
        $item['DESCRICAO'],
        $item['QUANTIDADE'],
        $item['CODIGO'],
        $item['IMAGEM']
    ));
}
