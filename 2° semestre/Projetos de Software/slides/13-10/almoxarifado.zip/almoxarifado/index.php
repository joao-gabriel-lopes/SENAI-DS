<?php
    Header ("Location: Paginas/ExibirEstoque.php");
?>