<?php
require_once 'Categoria.php';

class ItemEstoque
{
    private $id;
    private $categoria;         // Objeto da classe Categoria
    private $nome;
    private $descricao;
    private $quantidadeMinima;
    private $codigo;
    private $nomeImagem;

    public function __construct($id, $categoria, $nome, $descricao, $quantidadeMinima, $codigo, $nomeImagem)
    {
        $this->id = $id;
        $this->categoria = $categoria;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->quantidadeMinima = $quantidadeMinima;
        $this->codigo = $codigo;
        $this->nomeImagem = $nomeImagem;
    }

    public function Salvar()
    {
        $update = $this->id != null;
        $conexao = Conexao::GetConexao();
        if ($update) {
            $sql =
                "UPDATE 
                    ITEMESTOQUE 
                SET 
                    CATEGORIA_ID = :CATEGORIA_ID,
                    NOME = :NOME,
                    DESCRICAO = :DESCRICAO,
                    QUANTIDADE = :QUANTIDADE_MINIMA,
                    CODIGO = :CODIGO,
                    IMAGEM = :NOME_IMAGEM;
                WHERE 
                    ID = :ID";

            $comando = $conexao->prepare($sql);
            $comando->bindParam(":ID", $this->id);
        } else {
            $sql =
                "INSERT INTO ITEMESTOQUE(
                    CATEGORIA_ID, 
                    NOME, 
                    DESCRICAO, 
                    QUANTIDADE, 
                    CODIGO, 
                    IMAGEM
                )VALUES(
                    :CATEGORIA_ID, 
                    :NOME, 
                    :DESCRICAO, 
                    :QUANTIDADE, 
                    :CODIGO, 
                    :IMAGEM
                );";

            $comando = $conexao->prepare($sql);
            $comando->bindParam(":ID", $this->id);
        }

        $comando->bindParam(":CATEGORIA_ID", $this->categoria->getId());
        $comando->bindParam(":NOME", $this->nome);
        $comando->bindParam(":DESCRICAO", $this->descricao);
        $comando->bindParam(":QUANTIDADE_MINIMA", $this->quantidadeMinima);
        $comando->bindParam(":CODIGO", $this->codigo);
        $comando->bindParam(":NOME_IMAGEM", $this->nomeImagem);

        try {
            $comando->execute();

            if ($update){
                return $this->id;
            } else{
                return $conexao->lastInsertId();
            }
        } catch (Exception $e) {
            "Erro ao salvar ItemEstoque: " . $e->getMessage();
        }
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getCategoria()
    {
        return $this->categoria;
    }

    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }

    public function getQuantidadeMinima()
    {
        return $this->quantidadeMinima;
    }

    public function setQuantidadeMinima($quantidadeMinima)
    {
        $this->quantidadeMinima = $quantidadeMinima;
    }

    public function getCodigo()
    {
        return $this->codigo;
    }

    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function getNomeImagem()
    {
        return $this->nomeImagem;
    }

    public function setNomeImagem($nomeImagem)
    {
        $this->nomeImagem = $nomeImagem;
    }
}
